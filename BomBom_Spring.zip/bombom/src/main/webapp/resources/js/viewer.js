const viewer = new toastui.Editor({
	el: document.querySelector('#viewer'),
	viewer: true
});