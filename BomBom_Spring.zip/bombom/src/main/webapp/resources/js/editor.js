const editor = new toastui.Editor({
  el: document.querySelector("#editor"),
  height: "500px",
  initialEditType: "wysiwyg",
  placeholder: "내용을 입력해주세요",
  hooks: {
    addImageBlobHook: function (blob, callback) {
      const formData = new FormData();
      formData.append("image", blob);
      formData.append("uri", window.location.pathname);
      const imageURL = imageUpload(formData);
      console.log(imageURL);
      callback(imageURL, "image");
    },
  },
  language: 'ko-KR'
});

function imageUpload(formData) {		
  let imageURL;
  
  $.ajax({
	type: "post",
	url: "/bombom/image_upload.do",
	async: false,
	data: formData,
	processData: false,
	contentType: false,
    success: function (data) {
    imageURL = data;
    console.log(imageURL);
  },
    error: function(request, status, error) {
    alert(request + ", " + status + ", " + error);
  }
  });
  
  return imageURL;
}




