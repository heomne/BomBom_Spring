package com.bombom.api;

import lombok.Data;

@Data
public class BlogDTO {

	private String title;
	private String desc;
	private String link;
	private String blogger;
	private String date;
	
}
